ALTER TABLE `ol_admin_user` DROP COLUMN `is_online`;

DROP TABLE IF EXISTS `ol_live_issue`;

DROP TABLE IF EXISTS `ol_live_issue_log`;

DROP TABLE IF EXISTS `ol_live_issue_detail`;

DROP TABLE IF EXISTS `ol_live_issue_follow`;

DROP TABLE IF EXISTS `ol_live_issue_follow_map_user`;
