# 清空 库存变化记录
DELETE FROM ol_stuff_stock_log;
# 清空 库存
DELETE FROM ol_stuff_stock;
