#删除暑假课程报名状态为1的数据
DELETE FROM ol_sudoku_user_confirm WHERE status=1;